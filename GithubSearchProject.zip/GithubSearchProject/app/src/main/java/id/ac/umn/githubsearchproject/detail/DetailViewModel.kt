package id.ac.umn.githubsearchproject.detail

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import id.ac.umn.githubsearchproject.data.remote.ApiClient
import id.ac.umn.githubsearchproject.util.Result
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.launch

class DetailViewModel : ViewModel() {
    val resultUserDetail = MutableLiveData<Result>()
    val resultFollowerUser = MutableLiveData<Result>()
    val resultFollowingUser = MutableLiveData<Result>()

    fun getUserDetail(username : String){
        viewModelScope.launch {
            launch(Dispatchers.Main) {
                flow {
                    val response = ApiClient
                        .githubService
                        .getUserDetail(username)

                    emit(response)
                }.onStart {
                    resultUserDetail.value = Result.Loading(true)
                }.onCompletion {
                    resultUserDetail.value = Result.Loading(false)
                }.catch {
                    Log.e("ERROR", it.message.toString())
                    it.printStackTrace()
                    resultUserDetail.value = Result.Error(it)
                }.collect {
                    resultUserDetail.value = Result.Success(it)
                }
            }
        }
    }

    fun getFollowers(username : String){
        viewModelScope.launch {
            launch(Dispatchers.Main) {
                flow {
                    val response = ApiClient
                        .githubService
                        .getFollowerUser(username)

                    emit(response)
                }.onStart {
                    resultFollowerUser.value = Result.Loading(true)
                }.onCompletion {
                    resultFollowerUser.value = Result.Loading(false)
                }.catch {
                    Log.e("ERROR", it.message.toString())
                    it.printStackTrace()
                    resultFollowerUser.value = Result.Error(it)
                }.collect {
                    resultFollowerUser.value = Result.Success(it)
                }
            }
        }
    }

    fun getFollowing(username: String){
        viewModelScope.launch {
            launch(Dispatchers.Main) {
                flow {
                    val response = ApiClient
                        .githubService
                        .getFollowingUser(username)
                    emit(response)
                }.onStart {
                    resultFollowingUser.value = Result.Loading(true)
                }.onCompletion {
                    resultFollowingUser.value = Result.Loading(false)
                }.catch {
                    Log.e("ERROR", it.message.toString())
                    it.printStackTrace()
                    resultFollowingUser.value = Result.Error(it)
                }.collect {
                    resultFollowingUser.value = Result.Success(it)
                }
            }
        }
    }
}